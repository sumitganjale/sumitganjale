package com.tcl.msplatform.collections.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import jakarta.annotation.security.RolesAllowed;

@RestController
@RequestMapping("/collections")
public class CollectionsController {

    private WebClient webClient;

    public CollectionsController(WebClient webClient) {
        this.webClient = webClient;
    }

    @PreAuthorize("hasAuthority('SCOPE_TEST')")
    @GetMapping("/getCollections")
    @RolesAllowed({"Collections"})
    public String ping() {
        SecurityContext context = SecurityContextHolder.getContext();
        Authentication authentication = context.getAuthentication();

		/*
		 * String scopes = webClient .get() .uri("http://localhost:8040/BRS/getBRS")
		 * .retrieve() .bodyToMono(String.class) .block();
		 * System.out.println("scopes from collections->callme service: " + scopes);
		 */   return "Welcome to collections";
    }
}
